// funcion untuk melakukan pengecekkan inputan user
function Angka(){
    let angka = prompt("Masukkan Bilangan : ");

    // contoh confirm untuk mengecek data sudah benar
    let cek = confirm("Apakah Angka Yang Kamu Masukkan sudah benar?")
    
    if (angka % 2 === 0){
        alert( angka + " " + " Adalah Bilangan Genap");
    }

    else {
        alert (angka + " " + " Adalah Bilangan Ganjil");
    }

    }
    
    const tekan = document.getElementById("simpan")
   tekan.addEventListener("click", Angka)